

let  Person = require('./person');
//  let result = new Person('Bonka')
// console.log(result);

    
result.Person = Person;
